#include <cstdio>
#include <memory>
#include <rclcpp/rclcpp.hpp>
#include "can_msgs/msg/frame.hpp"
#include <linux/can/raw.h>
#include <boost/asio.hpp>

#include "test_pub_can.h"

using namespace std::chrono_literals;

TestPubCan::TestPubCan() : Node("canpub_node"),
                           led_switch_(""),
                           lin_vel_(0.0), // 초기 선형 속도는 0으로 설정
                           ang_vel_(0.0),
                           drive_rpm_(0),
                           lowByte(),
                           highByte()
{
  topicname_transmit << "CAN/can0/"
                     << "transmit";

  int8_t qos_depth = 0;

  const auto QOS_RKL10V = rclcpp::QoS(rclcpp::KeepLast(qos_depth)).reliable().durability_volatile();

  // publisher
  publisher_ = this->create_publisher<can_msgs::msg::Frame>(topicname_transmit.str(), 10);

  // subscriber
  cmdvel_subscriber_ = this->create_subscription<geometry_msgs::msg::Twist>(
      "/cmd_vel", QOS_RKL10V, std::bind(&TestPubCan::cmd_vel_callback, this, std::placeholders::_1));

  RCLCPP_DEBUG(this->get_logger(), "Thread started");

  // timer_ = this->create_wall_timer(10ms, std::bind(&TestPubCan::CanSend, this));
}

TestPubCan::~TestPubCan() {}

void TestPubCan::CanSend(uint lowByte, uint highByte)
{
  frame.id = 0x5;

  frame.dlc = 8;

  for (int i = 0; i < (int)frame.dlc; i++)
  {
    if (i == 0)
    {
      frame.data[i] = lowByte;
    }
    else if (i == 1)
    {
      frame.data[i] = highByte;
    }
    else
    {
      frame.data[i] = 0;
    }
  }
  std::stringstream out;
  out << std::string("S | ") << std::to_string(frame.id) << std::string("| ");
  for (int j = 0; j < (int)frame.dlc; j++)
  {
    out << std::to_string(frame.data[j]) << std::string(" ");
  }
  out << std::endl;
  RCLCPP_INFO(this->get_logger(), out.str().c_str());
  publisher_->publish(frame);
}

void TestPubCan::RpmTrans()
{
  // rpm 전송 테스트 파일

  std::stringstream out;

  std::vector<uint8_t> result(2);

  // std::cout << "Enter the node: ";
  // std::cin >> drive_rpm_;

  drive_rpm_ = (lin_vel_ * 60) / (0.32 * M_PI);
  out << std::string("rpm1 : ") << std::to_string(drive_rpm_);
  out << std::endl;
  drive_rpm_ = (uint)drive_rpm_;
  out << std::string("rpm2 : ") << std::to_string(drive_rpm_);
  out << std::endl;

  result[0] = (drive_rpm_ & 0xff);
  result[1] = ((drive_rpm_ >> 8) & 0xff);
  out << std::string("lowByte : ") << std::to_string(result[0]);
  out << std::endl;
  out << std::string("highByte : ") << std::to_string(result[1]);
  out << std::endl;

  CanSend(result[0], result[1]);
}

void TestPubCan::cmd_vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg)
{
  lin_vel_ = msg->linear.x;  // cmd_vel로부터 선형 속도를 갱신
  ang_vel_ = msg->angular.z; // cmd_vel로부터 각속도를 갱신, 현재 사용하지 않음

  RpmTrans();
}

void TestPubCan::CanSendConfirm(void)
{
  RCLCPP_DEBUG(this->get_logger(), "Message sent");
}

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<TestPubCan>());
  rclcpp::shutdown();
  return 0;
}

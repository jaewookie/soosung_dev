// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

/** @file TestPubCan.h
 *  @ingroup ROS2CAN_bridge
 *  @author Philipp Wuestenberg
 *  @brief  bidirectional ROS 2 to CAN interface with topics and service
 */

#ifndef __test_pub_can_H__
#define __test_pub_can_H__

#include <linux/can/raw.h>
#include <chrono>

#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "can_msgs/msg/frame.hpp"

/**
 * @brief The TestPubCan bridge connects a canbus with the ROS 2 topic system.
 * @details A nodes is provided, which provides the bridge from a ROS 2 topic to the CAN bus and from the CAN bus to a ROS 2 topic. The node functions as a bidirectional bridge and provides a service to publish a message and receive the answer with the fitting message id.
 */
class TestPubCan : public rclcpp::Node
{
public:
    /**
     * @brief constructor for TestPubCan class
     * @details Within the constructor the topic and service naming is done.
     */
    explicit TestPubCan(); // boost::asio::io_service& ios);
    virtual ~TestPubCan();
    /**
     * @brief destructor
     */

private:
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<can_msgs::msg::Frame>::SharedPtr publisher_;
    rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmdvel_subscriber_;
    can_msgs::msg::Frame current_frame;

    std::stringstream topicname_transmit;

    std::string led_switch_;

    can_msgs::msg::Frame frame;

    // vel
    float lin_vel_;
    float ang_vel_;

    // rpm and byte data
    uint16_t drive_rpm_;
    unsigned char lowByte;
    unsigned char highByte;

    void cmd_vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg);
    void CanSend(uint lowByte, uint highByte);
    void CanSendConfirm();
    void RpmTrans();

    // struct can_frame frame;
};
#endif
